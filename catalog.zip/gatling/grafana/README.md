Grafana
======


## Building

```
docker build -t davey/grafana .
```
