var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "3000",
        "ok": "3000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "28",
        "ok": "28",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2488",
        "ok": "2488",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "229",
        "ok": "229",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "248",
        "ok": "248",
        "ko": "-"
    },
    "percentiles1": {
        "total": "127",
        "ok": "127",
        "ko": "-"
    },
    "percentiles2": {
        "total": "303",
        "ok": "303",
        "ko": "-"
    },
    "percentiles3": {
        "total": "745",
        "ok": "745",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1166",
        "ok": "1166",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2869,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 104,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 27,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "22.621",
        "ok": "22.621",
        "ko": "-"
    }
},
contents: {
"req_home-8cf04": {
        type: "REQUEST",
        name: "Home",
path: "Home",
pathFormatted: "req_home-8cf04",
stats: {
    "name": "Home",
    "numberOfRequests": {
        "total": "1000",
        "ok": "1000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "55",
        "ok": "55",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2488",
        "ok": "2488",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "283",
        "ok": "283",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "292",
        "ok": "292",
        "ko": "-"
    },
    "percentiles1": {
        "total": "183",
        "ok": "183",
        "ko": "-"
    },
    "percentiles2": {
        "total": "356",
        "ok": "356",
        "ko": "-"
    },
    "percentiles3": {
        "total": "916",
        "ok": "916",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1442",
        "ok": "1442",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 938,
        "percentage": 94
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 37,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 25,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "7.54",
        "ok": "7.54",
        "ko": "-"
    }
}
    },"req_about-8f7f4": {
        type: "REQUEST",
        name: "About",
path: "About",
pathFormatted: "req_about-8f7f4",
stats: {
    "name": "About",
    "numberOfRequests": {
        "total": "1000",
        "ok": "1000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1247",
        "ok": "1247",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "330",
        "ok": "330",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "percentiles1": {
        "total": "268",
        "ok": "268",
        "ko": "-"
    },
    "percentiles2": {
        "total": "466",
        "ok": "466",
        "ko": "-"
    },
    "percentiles3": {
        "total": "842",
        "ok": "842",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1069",
        "ok": "1069",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 931,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 67,
        "percentage": 7
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "7.54",
        "ok": "7.54",
        "ko": "-"
    }
}
    },"req_contact-bbaff": {
        type: "REQUEST",
        name: "Contact",
path: "Contact",
pathFormatted: "req_contact-bbaff",
stats: {
    "name": "Contact",
    "numberOfRequests": {
        "total": "1000",
        "ok": "1000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "28",
        "ok": "28",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "407",
        "ok": "407",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "74",
        "ok": "74",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "percentiles1": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "percentiles2": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "percentiles3": {
        "total": "167",
        "ok": "167",
        "ko": "-"
    },
    "percentiles4": {
        "total": "261",
        "ok": "261",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1000,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "7.54",
        "ok": "7.54",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
