allUsersData = {
    
color: '#FF9D00',
name: 'All Users',
data: [
  [1457964882080,1],[1457964883080,1],[1457964884080,1],[1457964885080,1],[1457964886080,1],[1457964887080,1]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }

    , zIndex: 20
    , yAxis: 1
};