allUsersData = {
    
color: '#FF9D00',
name: 'All Users',
data: [
  [1457965232627,1],[1457965233627,1],[1457965234627,1],[1457965235627,1],[1457965236627,1],[1457965237627,1]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }

    , zIndex: 20
    , yAxis: 1
};