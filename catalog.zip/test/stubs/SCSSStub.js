/**
 * @providesModule SCSSStub
 */

module.exports = {};
